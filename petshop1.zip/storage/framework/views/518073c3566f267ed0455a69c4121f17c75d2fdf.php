<!--
Thành viên thực hiện:
- La Vĩnh Hòa
- Trương Hoàng Duy
- Nguyễn Hồ Thanh Bền
 -->
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests" />


    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
        integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css"
        href="http://fonts.googleapis.com/css?family=Ubuntu:regular,bold&subset=Latin">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

    <!-- <link rel="stylesheet" href="assets/css/fa6/all.min.css"> -->
    <title>Trang Chủ - Shop Pet</title>
</head>

<body>
    <div class="menu-mobile">
        <div class="menu-mobile__content">
            <div class="menu-mobile__head">
                <div class="menu-mobile__head-item menu-mobile__l">
                    <i class="fa-solid fa-list"></i>
                    <span>MENU</span>
                </div>
                <div class="menu-mobile__head-item menu-mobile__r">
                    <i class="fa-regular fa-user"></i>
                    <span><a href="login.html">LOGIN</a></span>

                </div>
                <div class="close-modal">
                    <i class="fa-solid fa-x"></i>
                </div>
            </div>
            <div class="menu-mobile__body">
                <ul class="menu-mobile__list">
                    <li class="menu-mobile__item">HOME <i class="fa-solid fa-angle-right"></i></li>
                    <li class="menu-mobile__item">SHOP <i class="fa-solid fa-angle-right"></i></li>
                    <li class="menu-mobile__item item-featured">
                        FEATURED <i class="fa-solid fa-angle-right"></i>
                        <div class="dropmenu-m">
                            <div class="menu-item">
                                <h5 class="menu-item__title">BLOG LAYOUTS</h5>
                                <div class="separate"></div>
                                <ul class="menu-item__list">
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Blog Standar Sidebar Left</a>
                                    </li>
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Blog Standar Sidebar Right</a>
                                    </li>
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Blog Grid Sidebar LeftNEW</a>
                                    </li>
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Blog Grid No SidebarNEW</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="menu-item">
                                <h5 class="menu-item__title">PRODUCT LAYOUTS</h5>
                                <div class="separate"></div>
                                <ul class="menu-item__list">
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Product Large ImagesNEW</a>
                                    </li>
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Product Extended</a>
                                    </li>
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Product Gallery</a>
                                    </li>
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Product StickyHOT</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="menu-item">
                                <h5 class="menu-item__title">PRODUCT TYPES</h5>
                                <div class="separate"></div>
                                <ul class="menu-item__list">
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Variable</a>
                                    </li>
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Video</a>
                                    </li>
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Affiliate</a>
                                    </li>
                                    <li class="menu-item__link">
                                        <a href="" class="menu-item__link-item">Simple</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="arrow-up"></div>
                        </div>
                    </li>
                    <li class="menu-mobile__item">PAGES <i class="fa-solid fa-angle-right"></i></li>
                    <li class="menu-mobile__item">ELEMENT </li>
                </ul>
            </div>
            <!-- <div class="menu-mobile__footer">
                 
                 <span>CLOSE</span>
             </div> -->
        </div>
    </div>
    <header class="header">

        <div class="rp-navbar">
            <i class="rp-navbar__icon fa-solid fa-bars"></i>
        </div>
        <div class="header-logo">
            <a class="header-logo__link" href="/">
                <img class="header-logo__image"
                    src="https://cdn.shopify.com/s/files/1/0324/2334/6235/files/logo.png?v=1613757546" alt="">
            </a>
        </div>
        <nav class="nav">
            <ul class="nav-list-center">
                <li class="nav-item"><a href="/">Home</a></li>
                <li class="nav-item">Shop</li>
                <li class="nav-item item-hover">
                    <div class="nav-item__notify cl-red">
                        <span class="nav-item__notify--hot">HOT</span>
                    </div>
                    Featured
                    <div class="dropmenu">
                        <div class="menu-item">
                            <h5 class="menu-item__title">BLOG LAYOUTS</h5>
                            <div class="separate"></div>
                            <ul class="menu-item__list">
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Blog Standar Sidebar Left</a>
                                </li>
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Blog Standar Sidebar Right</a>
                                </li>
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Blog Grid Sidebar LeftNEW</a>
                                </li>
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Blog Grid No SidebarNEW</a>
                                </li>
                            </ul>
                        </div>
                        <div class="menu-item">
                            <h5 class="menu-item__title">PRODUCT LAYOUTS</h5>
                            <div class="separate"></div>
                            <ul class="menu-item__list">
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Product Large ImagesNEW</a>
                                </li>
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Product Extended</a>
                                </li>
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Product Gallery</a>
                                </li>
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Product StickyHOT</a>
                                </li>
                            </ul>
                        </div>
                        <div class="menu-item">
                            <h5 class="menu-item__title">PRODUCT TYPES</h5>
                            <div class="separate"></div>
                            <ul class="menu-item__list">
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Variable</a>
                                </li>
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Video</a>
                                </li>
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Affiliate</a>
                                </li>
                                <li class="menu-item__link">
                                    <a href="" class="menu-item__link-item">Simple</a>
                                </li>
                            </ul>
                        </div>
                        <div class="arrow-up"></div>
                    </div>
                </li>
                <li class="nav-item">
                    Page
                    <div class="nav-item__notify cl-blue">
                        <span class="nav-item__notify--new">NEW</span>
                    </div>
                </li>
            </ul>
        </nav>
        <div class="header-right">
            <ul class="nav-list-right">
                <li class="nav-item nav-item-r">
                    <input placeholder="Search anything" type="search" name="search" class="search">
                    <i class="fa-solid btn-search fa-magnifying-glass"></i>
                </li>
                <li class="nav-item nav-item-r">
                    <a href="login.html"><i class="fa-regular fa-user"></i></a>
                </li>
                <li class="nav-item nav-item-r">
                    <a href="cart.html"><i class="fa-solid fa-cart-shopping"></i></a>
                    <div class="total-cart">
                        <span class="total-cart__number">3</span>
                    </div>
                </li>
            </ul>
        </div>
    </header>

    <?php echo $__env->yieldContent('content'); ?>

    <footer>
        <div class="footer-container">
            <div class="footer-section">
                <h3 class="footer-section__title">HELP & INFOMATION</h3>
                <ul class="footer-section__list">
                    <li class="footer-section__item">Help</li>
                    <li class="footer-section__item">Track Order</li>
                    <li class="footer-section__item">Delivery & Returns</li>
                    <li class="footer-section__item">10% Member Discount</li>
                </ul>
            </div>
            <div class="footer-section">
                <h3 class="footer-section__title">ABOUT US</h3>
                <ul class="footer-section__list">
                    <li class="footer-section__item">Careers at Famipet</li>
                    <li class="footer-section__item">Corporate Responsibility</li>
                    <li class="footer-section__item">Investors Site</li>
                    <li class="footer-section__item">Contact Us</li>
                </ul>
            </div>
            <div class="footer-section">
                <h3 class="footer-section__title">CATEGORIES</h3>
                <ul class="footer-section__list">
                    <li class="footer-section__item">High-Quality Meat</li>
                    <li class="footer-section__item">Limited-Ingredient Diet</li>
                    <li class="footer-section__item">Care and Feeding</li>
                    <li class="footer-section__item">Commitment to Safety</li>
                </ul>
            </div>
            <div class="footer-section">
                <h3 class="footer-section__title">HELP & INFOMATION</h3>
                <p>News & updates from FamipetStore.
                    No spam, we promise.</p>
                <div class="footer-section__form">
                    <input type="text">
                    <button>SIGN UP</button>
                </div>
            </div>
        </div>

    </footer>
    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI="
        crossorigin="anonymous"></script>
    <script src="assets/js/common.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\petshop\resources\views\layout\client\master.blade.php ENDPATH**/ ?>