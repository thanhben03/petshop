
<?php $__env->startSection('content'); ?>
    <main>
        <article class="wrap-login">
            <h1 class="login-title">Change Password</h1>
            <section class="login">
                <form action="<?php echo e(route('changePassword')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(session()->has('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('msg')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session()->get('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="login__account">
                        <div class="login__wrap-input">
                            <input type="text" value="<?php echo e(old('current_psw')); ?>" placeholder="Mật khẩu hiện tại" name="current_psw"
                                class="login__input login-email">
                        </div>
                        <div class="login__wrap-input">
                            <input type="text" placeholder="Mật khẩu mới" name="new_psw"
                                class="login__input login-email">
                        </div>
                        <div class="login__wrap-input">
                            <input type="text" placeholder="Nhập lại mật khẩu mới " name="re_newpsw"
                                class="login__input login-password">
                        </div>
                        <?php if(session()->has('error2')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('error2')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="login__account-btn">
                        <button type="submit" class="btn-login">Thay Đổi</button>
                        
                    </div>
                </form>


            </section>
        </article>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.client.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petshop\resources\views/client/profile/password.blade.php ENDPATH**/ ?>