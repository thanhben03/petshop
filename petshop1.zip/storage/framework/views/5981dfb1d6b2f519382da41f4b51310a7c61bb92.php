
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <h3 class="page-title">Edit</h3>
        </div>
    </div>
    <div class="card">
        <?php if($errors->any()): ?>
            <div class="card-header">
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <form action="<?php echo e(route('product.update', $data)); ?>" method="POST" id="form-edit-product" enctype="multipart/form-data">
                
                
                
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Name</label>
                    <input type="text" class="form-control" id="" value="<?php echo e($data->name); ?>" name="name">
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Description</label>
                    <input type="text" class="form-control" id="" value="<?php echo e($data->desc); ?>" name="desc">
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Image</label>
                    <input type="file" class="form-control" id="" value="<?php echo e($data->image); ?>" name="image">
                    <img style="width: 100px" src="<?php echo e(asset('storage').'/'.$data->image); ?>" alt="">
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Category</label>
                    
                    <select name="category_id" id="">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id == $data->category->id): ?>
                                <option selected value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Inventory</label>
                    
                    <select name="inventory_id" id="">
                        <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id == $data->inventory->id): ?>
                                <option selected value="<?php echo e($item->id); ?>"><?php echo e($item->quantity); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->quantity); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Discount</label>
                    <select name="discount_id" id="">
                        <?php $__currentLoopData = $discount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id == $data->discount->id): ?>
                                <option selected value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Price</label>
                    <input type="text" class="form-control" id="" value="<?php echo e($data->price); ?>" name="price">
                </div>
                <button class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $("#form-edit-product").submit(function(e) {
            e.preventDefault();
            toastr.options = {
                "progressBar": true
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            // console.log($("#form-edit-product").serialize()); return;
            $.ajax({
                type: "PUT",
                url: $(this).attr('action'),
                data: new FormData(this),
                dataType: "json",
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.status == 'success') {
                        toastr.success(response.msg, 'Success!')
                    }
                },
                error: function() {
                    console.log('2');
                    toastr.error('Chỉnh sửa thất bại !', 'Error!')
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petshop\resources\views\admin\product\edit.blade.php ENDPATH**/ ?>