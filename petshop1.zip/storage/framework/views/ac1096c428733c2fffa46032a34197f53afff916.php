
<?php $__env->startSection('content'); ?>
    <div class="modal fade bd-example-modal-lg" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Xác nhận địa chỉ thanh toán</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="fullname" class="col-form-label">Full Name:</label>
                            <input type="text" class="form-control" value="<?php echo e($address_payment->fullname ?? ''); ?>"
                                name="fullname" id="fullname">
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Address:</label>
                            <input type="text" value="<?php echo e($address_payment->address ?? ''); ?>" class="form-control"
                                placeholder="Ex: An Thạnh Trung, Chợ Mới, An Giang" name="address" id="address">

                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Phone Number:</label>
                            <input type="text" value="<?php echo e($address_payment->phone ?? ''); ?>" class="form-control"
                                name="phone" id="phone">

                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" id="save-address" class="btn btn-primary">Save</button>
                </div>
            </div>
        </div>
    </div>
    <main>
        <article class="wrap-cart">
            <section class="section section-cart">
                <div class="btn-group" role="group" aria-label="Basic example">
                    <a href="<?php echo e(route('cart')); ?>" class="btn btn-secondary">Giỏ Hàng</a>
                    <a href="<?php echo e(route('purchased')); ?>" class="btn btn-secondary ml-2">Lịch sử mua hàng</a>
                </div>
                <table class="section-cart__wrap cart-d">
                    <thead>
                        <tr>
                            <th colspan="2">PRODUCT NAME</th>
                            <th>PRICE</th>
                            <th>QUANTITY</th>
                            <th>TOTAL</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody class="contain-cart">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="2" id="test">
                                    <div class="cart">
                                        <img src="<?php echo e(asset('storage/' . $item['product_info']->image)); ?>" alt=""
                                            class="cart-info__img">
                                        <span class="cart-info__name"><?php echo e($item['product_info']->name); ?></span>

                                    </div>
                                </td>
                                <td class="cart-line-2">
                                    <p class="cart-price-label mgl-8">Price: </p>
                                    <span class="cart-price-value"><?php echo e(number_format($item['product_info']->price)); ?>đ</span>
                                    <div class="product-info__quantity product-info__quantity-m">
                                        <span class="product-info__quantity-number number-13"><?php echo e($item['quantity']); ?></span>
                                        <div class="product-info__volume">
                                            <i id="13" class="fa-solid fa-caret-up increase increase-up-13"></i>
                                            <i id="13" class="fa-solid fa-caret-down decrease decrease-down-13"></i>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="">
                                        <span>x<?php echo e($item['quantity']); ?></span>
                                        
                                    </div>
                                </td>
                                <td class="cart-total-wrap">
                                    <p class="cart-price-label mgl-8">Total: <?php echo e(number_format($item['total'])); ?>đ</p>
                                    <span class="cart-total-m"></span>
                                    <i id="13" class="fa-solid fa-trash btnDelete btnDelete-m"></i>
                                </td>
                                <td class="btnDelete" data-id="13">
                                    <span>
                                        <?php if($item['status']): ?>
                                            Đã xác nhận
                                        <?php else: ?>
                                            Chờ duyệt
                                        <?php endif; ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </section>

        </article>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.client.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petshop\resources\views/client/purchased.blade.php ENDPATH**/ ?>