
<?php $__env->startSection('content'); ?>
    <main>
        <article class="wrap-register">
            <h1 class="register-title">Đăng ký thành viên!</h1>
            <section class="login">
                <?php if(session()->has('msg')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('msg')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                <?php endif; ?>
                </div>
                <form action="<?php echo e(route('processRegister')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="login__wrap-input col-lg-6">
                            <input type="text" placeholder="Full Name" name="fullname"
                                class="login__input register__input">
                        </div>
                        <div class="login__wrap-input col-lg-6">
                            <input type="text" placeholder="Address" name="address" class="login__input register__input">
                        </div>

                    </div>
                    <div class="row">
                        <div class="login__wrap-input col-lg-6">
                            <input type="text" placeholder="Email" name="email" class="login__input register__input">
                        </div>
                        <div class="login__wrap-input col-lg-6">
                            <input type="text" placeholder="Username" name="username"
                                class="login__input register__input">
                        </div>
                    </div>
                    <div class="row">
                        <div class="login__wrap-input col-lg-6">
                            <input type="password" placeholder="Password" name="password"
                                class="login__input register__input">
                        </div>
                        <div class="login__wrap-input col-lg-6">
                            <input type="password" placeholder="Re-Password" name="re-password"
                                class="login__input register__input">
                        </div>
                    </div>
                    <div class="register__account-btn">
                        <button type="submit" class="btn-login">LOG IN</button>
                        <div class="login__box-register">
                            <p>YOU HAVE AN ACCOUNT ?</p>
                            <a href="<?php echo e(route('login')); ?>">Login Now --&gt;</a>
                        </div>
                    </div>
                </form>


            </section>
        </article>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.client.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petshop\resources\views/client/register.blade.php ENDPATH**/ ?>