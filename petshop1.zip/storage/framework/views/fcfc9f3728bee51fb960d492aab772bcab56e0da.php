
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <h3 class="page-title">Edit</h3>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <div class="alert alert-danger" style="display: none">
                <ul class="error-create-product">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        
        <div class="card-body">
            <form action="<?php echo e(route('product.store')); ?>" method="POST" id="form-create-product"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Name</label>
                    <input type="text" class="form-control" id="" value="" name="name">
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Description</label>
                    <input type="text" class="form-control" id="" value="" name="desc">
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Image</label>
                    <input type="file" class="form-control" id="" value="" name="image">
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Category</label>

                    <select name="category_id" id="">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($loop->first): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>">
                                <?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Inventory</label>
                    
                    <select name="inventory_id" id="">
                        <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($loop->first): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>">
                                <?php echo e($item->quantity); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Discount</label>
                    <select name="discount_id" id="">
                        <?php $__currentLoopData = $discount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($loop->first): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>">
                                <?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Price</label>
                    <input type="text" class="form-control" id="" value="" name="price">
                </div>
                <button class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $("#form-create-product").submit(function(e) {
            e.preventDefault();
            // let formData = new FormData($(this));
            $.ajax({
                type: "POST",
                url: $(this).attr('action'),
                data: new FormData(this),
                dataType: "json",
                processData: false,
                contentType: false,
                success: function(res) {
                    if (res.status == 'success') {
                        toastr.success(res.msg, 'success!');
                        window.location.reload()
                    }
                },
                error: function(res) {
                    let arrErr = Object.entries(res.responseJSON.errors);
                    let html = '';
                    arrErr.forEach(err => {
                        html += `<li>${err[1][0]}</li>`;
                    });
                    $(".error-create-product").html(html);
                    $(".error-create-product").parent()[0].style.display = 'block';
                    console.log(res);
                    toastr.error('Đã xảy ra lỗi!', 'error!')
                }
            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petshop\resources\views/admin/product/create.blade.php ENDPATH**/ ?>