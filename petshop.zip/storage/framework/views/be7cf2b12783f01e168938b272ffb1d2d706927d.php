
<?php $__env->startSection('content'); ?>
    <main>
        <article class="wrap-cart">
            <section class="section section-cart">

                <table class="section-cart__wrap cart-d">
                    <thead>
                        <tr>
                            <th colspan="2">PRODUCT NAME</th>
                            <th>PRICE</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody class="contain-cart">
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="2" id="test">
                                    <div class="cart">
                                        <img src="<?php echo e(asset('storage/' . $item->product->image)); ?>" alt=""
                                            class="cart-info__img">
                                        <h3 class="cart-info__name">
                                            <a href="<?php echo e(route('view-product',$item->product->id)); ?>"><?php echo e($item->product->name); ?></a>
                                        </h3>

                                    </div>
                                </td>
                                <td class="cart-line-2">
                                    <p class="cart-price-label mgl-8">Price: </p>
                                    <span class="cart-price-value"><?php echo e(number_format($item->product->price)); ?>đ</span>
                                    <div class="product-info__quantity product-info__quantity-m">
                                        <span class="product-info__quantity-number number-13"><?php echo e($item['quantity']); ?></span>
                                        <div class="product-info__volume">
                                            <i id="13" class="fa-solid fa-caret-up increase increase-up-13"></i>
                                            <i id="13" class="fa-solid fa-caret-down decrease decrease-down-13"></i>
                                        </div>
                                    </div>
                                </td>
                                
                               
                                <td class="btnDelete" onclick="deleteCart(<?php echo e($item->product->id); ?>)" data-id="13">
                                    <i class="fa-solid fa-trash"></i>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </section>

        </article>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.client.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petshop\resources\views/client/profile/wishlist.blade.php ENDPATH**/ ?>