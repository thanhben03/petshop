
<?php $__env->startSection('content'); ?>
    <main>
        <article>
            <section class="section banner">
                <img class="banner-img" src="https://cdn.shopify.com/s/files/1/0324/2334/6235/files/slide1.3.jpg?v=1613757500"
                    alt="">
                <div class="banner-content">
                    <div class="banner-wrap">
                        <h1 class="banner__title">Famipet Shop</h1>
                        <h3 class="banner__subtitle">Everything For Pets</h2>
                    </div>
                    <button class="banner__button">Shop Now</button>
                </div>
            </section>

            <section class="section product" id="products">
                <h1 class="heading-section product__title">New Arrivals</h1>
                <div class="product-list">
                    <a href="product.html?item=1" id="item-1" class="product-item">
                        <img src="<?php echo e(asset('images/product/1.png')); ?>" class="product-item__img" alt="">
                        <div class="product-item__info">
                            <h3 class="product-name">Royal Canin Maxi 5+</h3>
                            <h4 class="product-price">$22.00</h4>
                        </div>
                    </a>
                    <a href="product.html?item=2" id="item-2" class="product-item">
                        <img src="<?php echo e(asset('images/product/2.png')); ?>" class="product-item__img" alt="">
                        <div class="product-item__info">
                            <h3 class="product-name">Wet Cat Food</h3>
                            <h4 class="product-price">$46.00</h4>
                        </div>
                    </a>
                    <a href="product.html?item=3" id="item-3" class="product-item">
                        <img src="<?php echo e(asset('images/product/3.png')); ?>" class="product-item__img" alt="">
                        <div class="product-item__info">
                            <h3 class="product-name">Dry Dog Food</h3>
                            <h4 class="product-price">$15.00</h4>
                        </div>
                    </a>
                    <a href="product.html?item=4" id="item-" class="product-item">
                        <img src="<?php echo e(asset('images/product/4.png')); ?>" class="product-item__img" alt="">
                        <div class="product-item__info">
                            <h3 class="product-name">Royal Canin Exigent Cats</h3>
                            <h4 class="product-price">$23.00</h4>
                        </div>
                    </a>
                    <a href="product.html?item=5" id="item-" class="product-item">
                        <img src="<?php echo e(asset('images/product/5.png')); ?>" class="product-item__img" alt="">
                        <div class="product-item__info">
                            <h3 class="product-name">Rocco Classic</h3>
                            <h4 class="product-price">$25.00</h4>
                        </div>
                    </a>
                    <a href="product.html?item=6" id="item-" class="product-item">
                        <img src="<?php echo e(asset('images/product/6.png')); ?>" class="product-item__img" alt="">
                        <div class="product-item__info">
                            <h3 class="product-name">Veterinary Diet Canine</h3>
                            <h4 class="product-price">$22.00</h4>
                        </div>
                    </a>
                    <a href="product.html?item=7" id="item-" class="product-item">
                        <img src="<?php echo e(asset('images/product/7.png')); ?>" class="product-item__img" alt="">
                        <div class="product-item__info">
                            <h3 class="product-name">Wilderness Dry Dog Food</h3>
                            <h4 class="product-price">$43.00</h4>
                        </div>
                    </a>
                    <a href="product.html?item=8" id="item-" class="product-item">
                        <img src="<?php echo e(asset('images/product/8.png')); ?>" class="product-item__img" alt="">
                        <div class="product-item__info">
                            <h3 class="product-name">Wellbeloved Dry Dog Food</h3>
                            <h4 class="product-price">$61.00</h4>
                        </div>
                    </a>
                </div>
                <ul class="pagination">
                    <li class="pagination-item"><a href="">Pre</a></li>
                    <li class="pagination-item"><a href="">1</a></li>
                    <li class="pagination-item"><a href="">2</a></li>
                    <li class="pagination-item"><a href="">3</a></li>
                    <li class="pagination-item"><a href="">Next</a></li>
                </ul>
            </section>

            <section class="section promotion">
                <img src="<?php echo e(asset('images/promotion/img_countdown.png')); ?>" alt="" class="promotion__img">
                <div class="promotion-content">
                    <h1 class="promotion-content__title">Keep Your Pets Pleasure</h1>
                    <div class="promotion-content-discount">
                        <h3 class="promotion-content-discount__nosale">$34.90</h3>
                        <h3 class="promotion-content-discount__sale">$33.90</h3>
                    </div>
                    <div class="promotion-content__label">
                        <span>With the dogs on a mission to create a serum that would eliminate the canine allergies
                            among the humans, their feline foes are on their paws hatching plans to obstruct the top
                            secret canine project.</span>
                    </div>
                    <div class="promotion-countdown">
                        <ul class="promotion-countdown__list">
                            <li class="promotion-countdown__item">
                                <p class="promotion-countdown__label promotion-countdown__day-number">46</p>
                                <p class="promotion-countdown__day-text">DAY</p>
                            </li>
                            <li class="promotion-countdown__item">
                                <p class="promotion-countdown__label promotion-countdown__hour-number">13</p>
                                <p class="promotion-countdown__hour-text">HOURS</p>
                            </li>
                            <li class="promotion-countdown__item">
                                <p class="promotion-countdown__label promotion-countdown__min-number">51</p>
                                <p class="promotion-countdown__min-text">MINS</p>
                            </li>
                            <li class="promotion-countdown__item">
                                <p class="promotion-countdown__label promotion-countdown__sec-number">51</p>
                                <p class="promotion-countdown__sec-text">SECS</p>
                            </li>
                            <!-- <li class="promotion-countdown__item"></li> -->
                        </ul>
                    </div>
                    <button class="promotion-content__button"><a href="#products">SHOP NOW</a></button>
                </div>
            </section>

            <section class="section get-update">
                <div class="get-update-container">
                    <h1>GET UPDATE</h1>
                    <h4>Subscribe our newsletter and get discount 30% off</h4>
                    <div class="get-update__box">
                        <input placeholder="Enter your email" type="text" class="get-update__input">
                        <button>SIGN UP</button>
                    </div>
                </div>
            </section>
            <section class="section social-shop">
                <h1 class="heading-section">Instagram Shop</h1>
                <h4>@Family  pet</h4>
                <div class="social-shop__img-wrap">
                    <img src="<?php echo e(asset('images/social/1.png')); ?>" alt="" class="social-shop__img-item">
                    <img src="<?php echo e(asset('images/social/2.png')); ?>" alt="" class="social-shop__img-item">
                    <img src="<?php echo e(asset('images/social/3.png')); ?>" alt="" class="social-shop__img-item">
                    <img src="<?php echo e(asset('images/social/4.png')); ?>" alt="" class="social-shop__img-item">
                </div>
            </section>
        </article>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.client.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petshop\resources\views\client\index.blade.php ENDPATH**/ ?>