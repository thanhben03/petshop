
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <h3 class="page-title">Edit</h3>
        </div>
    </div>
    <div class="card">
        <?php if($errors->any()): ?>
            <div class="card-header">
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <form action="<?php echo e(route('order.update', $data)); ?>" method="POST" id="form-edit-order">
                
                <?php echo method_field('PUT'); ?>
                
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Trạng thái</label>
                    <select name="status" id="">
                        <option <?php if($data->status == 0): ?> selected <?php endif; ?> value="0">
                            Chờ duyệt</option>
                        <option <?php if($data->status == 1): ?> selected <?php endif; ?> value="1">
                            Đã duyệt</option>

                    </select>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Tổng tiền</label>
                    <input type="text" class="form-control" id="" value="<?php echo e($data->total); ?>" name="total">
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Số lượng</label>
                    <input type="text" class="form-control" id="" value="<?php echo e($data->quantity); ?>" name="quantity">
                    
                </div>
                

                <button class="btn btn-primary">Chỉnh sửa</button>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $("#form-edit-order").submit(function(e) {
            e.preventDefault();
            toastr.options = {
                "progressBar": true
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            // console.log($("#form-edit-product").serialize()); return;
            $.ajax({
                type: "POST",
                url: $(this).attr('action'),
                data: new FormData(this),
                dataType: "json",
                processData: false,
                contentType: false,
                success: function(response) {

                    if (response.status == 'success') {
                        toastr.success(response.msg, 'Success!')
                        // setTimeout(() => {
                        //     window.location.reload()

                        // }, 1200);
                    }
                },
                error: function() {
                    console.log('2');
                    toastr.error('Chỉnh sửa thất bại !', 'Error!')
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petshop\resources\views/admin/order/edit.blade.php ENDPATH**/ ?>