
<?php $__env->startSection('content'); ?>
    <main>
        <article class="wrap-login">
            <h1 class="login-title">Đăng nhập hệ thống!</h1>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(session()->has('msg')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('msg')); ?>

                </div>
            <?php endif; ?>
            <section class="login">
                <form action="<?php echo e(route('processLogin')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="login__account">
                        <div class="login__wrap-input">
                            <input type="text" placeholder="username" 
                            name="username"
                            class="login__input login-email">
                        </div>
                        <div class="login__wrap-input">
                            <input type="text" placeholder="Password" 
                            name="password"
                            class="login__input login-password">
                        </div>
                        <a href="#">Forgot your password?</a>
                    </div>
                    <div class="login__account-btn">
                        <button type="submit" class="btn-login">LOG IN</button>
                        <div class="login__box-register">
                            <p>DON'T HAVE AN ACCOUNT ?</p>
                            <a href="<?php echo e(route('register')); ?>">Register Now --&gt;</a>
                        </div>
                    </div>
                </form>


            </section>
        </article>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.client.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petshop\resources\views/client/login.blade.php ENDPATH**/ ?>