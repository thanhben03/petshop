
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <h3 class="page-title">Danh sách sản phẩm</h3>
            
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <table class="table table-striped" id="table-order-index">
                <thead>
                    <tr>
                        
                        <th>HỌ TÊN</th>
                        <th>TÊN SP</th>
                        <th>ĐƠN GIÁ</th>
                        <th>SỐ LƯỢNG</th>
                        <th>TỔNG TIỀN</th>
                        <th>SỐ LƯỢNG</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            let table = $('#table-order-index').DataTable({
                dom: 'Blrtip',
                // select: true,
                processing: true,
                serverSide: true,
                ajax: '<?php echo route('order.api'); ?>',
                // columnDefs: [{
                //     className: "not-export",
                //     "targets": [3]
                // }],
                columns: [{
                        data: 'username',
                        name: 'username'
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'price',
                        name: 'price'
                    },
                    {
                        data: 'image',
                        name: 'image'
                    },
                    {
                        data: 'total',
                        name: 'total'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },

                    {
                        data: 'edit',
                        targets: 6,
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row, meta) {
                            return `<a class="btn btn-primary" href="${data}">
                            Edit
                        </a>`;
                        }
                    },
                    {
                        data: 'destroy',
                        targets: 7,
                        orderable: false,
                        searchable: false,
                        render: function(data, type, row, meta) {
                            return `<form action="${data}" method="post" id="form-delete-order">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type='submit' class="btn-delete btn btn-danger">Delete</button>
                            </form>`;
                        }
                    },

                ]
            });
            console.log(table.data);
            $("#form-delete-order").submit(function(e) {
                e.preventDefault();
                console.log('123');
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\petshop\resources\views/admin/order/index.blade.php ENDPATH**/ ?>